/*
    Author: Mari Anavisca
        Date: 10/1
        Purpose: 3.5 Performance Assessment: Flow Control
*/

/* =========================================
   GREENWAY PARK TRAIL DATA
========================================= */

const trails = [
    { name: "River Walk", difficulty: "low", time: 20 },
    { name: "Forest Loop", difficulty: "medium", time: 45 },
    { name: "Hill Summit Trail", difficulty: "high", time: 90 },
    { name: "Lake Side Path", difficulty: "low", time: 30 },
    { name: "Rock Ridge Trail", difficulty: "high", time: 75 },
	{ name: "Mountain View Trail", difficulty: "medium", time: 75 },
	{ name: "Sunset Valley Trail", difficulty: "hard", time: 120 },
	{ name: "Marana6296 Trail", difficulty: "high", time: 75 }
];

const trailContainer = document.querySelector("#trailContainer");

for (let counter = 0; counter < trails.length; counter++) {
    const trail = trails[counter];

    trailContainer.innerHTML += `
        <article class="card">
            <h3>${trail.name}</h3>
            <p>Difficulty: ${trail.difficulty}</p>
            <p>Average Time: ${trail.time}</p>
        </article>
    `;
}


/* =========================================
   TODO: FORM LOGIC
========================================= */

const trailForm = document.querySelector("#trailForm");
const result = document.querySelector("#result");

trailForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const pets = document.querySelector('input[name="pets"]:checked').value;
    const experience = document.querySelector("#experience").value;

    let recommendation;

    if (pets === "yes" && experience === "low") {
        recommendation = "River Walk";
    }
    else if (pets === "yes" && (experience === "medium" || experience === "high")) {
        recommendation = "Forest Loop";
    }
    else if (pets === "no" && experience === "low") {
        recommendation = "Lake Side Path";
    }
    else if (pets === "no" && experience === "medium") {
        recommendation = "Forest Loop";
    }
    else if (pets === "no" && experience === "high") {
        recommendation = "Rock Ridge Trail";
    }
    else {
        recommendation = "River Walk";
    }

    result.innerHTML = `<p>Recommended Trail: ${recommendation}</p>`;
});